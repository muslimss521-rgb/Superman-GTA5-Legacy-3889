#include "script.h"
#include "controller.h"
#include <windows.h>
#include <mmsystem.h>
#include <string>
#include <cmath>
#pragma comment(lib,"winmm.lib")

static bool gOn=false, gFlight=false, gFast=false, gSpeed=false, gForcedAnim=false;
static DWORD gLastAction=0;
static bool gPrevKey[256]{};

static bool KeyDown(int vk){ return (GetAsyncKeyState(vk)&0x8000)!=0; }
static bool KeyPressed(int vk){
    bool now=KeyDown(vk), was=gPrevKey[vk];
    gPrevKey[vk]=now;
    return now && !was;
}
static bool KBDown(int vk){ return KeyDown(vk); }

static void Notify(const char* msg){
    UI::_SET_NOTIFICATION_TEXT_ENTRY("STRING");
    UI::_ADD_TEXT_COMPONENT_STRING((LPSTR)msg);
    UI::_DRAW_NOTIFICATION(false,false);
}
static std::string Root(){
    char b[MAX_PATH]={0}; GetCurrentDirectoryA(MAX_PATH,b); return std::string(b);
}
static void Snd(const char* name){
    std::string p=Root()+"\\SupermanSounds\\"+name;
    PlaySoundA(p.c_str(),NULL,SND_FILENAME|SND_ASYNC|SND_NODEFAULT);
}
static bool Cooldown(DWORD ms){
    DWORD n=GetTickCount();
    if(n-gLastAction<ms) return false;
    gLastAction=n; return true;
}
static void Powers(Ped p,bool on){
    ENTITY::SET_ENTITY_INVINCIBLE(p,on);
    PLAYER::SET_PLAYER_INVINCIBLE(PLAYER::PLAYER_ID(),on);
    PED::SET_PED_CAN_RAGDOLL(p,!on);
    PED::SET_PED_CAN_RAGDOLL_FROM_PLAYER_IMPACT(p,!on);
}
static void PlayAnim(Ped p,const char* dict,const char* clip,float rate=8.0f,int flags=49){
    if(!STREAMING::HAS_ANIM_DICT_LOADED((char*)dict)){
        STREAMING::REQUEST_ANIM_DICT((char*)dict); return;
    }
    AI::TASK_PLAY_ANIM(p,(char*)dict,(char*)clip,rate,-8.0f,-1,flags,0.0f,false,false,false);
}
static void LoadAnim(const char* dict){
    if(!STREAMING::HAS_ANIM_DICT_LOADED((char*)dict))
        STREAMING::REQUEST_ANIM_DICT((char*)dict);
}
static void Animations(Ped p){
    LoadAnim("amb@world_human_cheering@male_a");
    LoadAnim("misscarsteal4@actor");
    if(gForcedAnim && gFlight)
        PlayAnim(p,"amb@world_human_cheering@male_a","base",4.0f,49);
}
static Vector3 Fwd(Ped p){ return ENTITY::GET_ENTITY_FORWARD_VECTOR(p); }
static Vector3 Pos(Ped p,float x,float y,float z){
    return ENTITY::GET_OFFSET_FROM_ENTITY_IN_WORLD_COORDS(p,x,y,z);
}
static void Beam(Ped p,float range,int r,int g,int b,float damage){
    Vector3 a=Pos(p,0,0.75f,0.65f), f=Fwd(p);
    Vector3 e={a.x+f.x*range,a.y+f.y*range,a.z+f.z*range};
    GRAPHICS::DRAW_LINE(a.x,a.y,a.z,e.x,e.y,e.z,r,g,b,255);
    FIRE::ADD_EXPLOSION(e.x,e.y,e.z,2,damage,false,true,0.0f);
}
static bool PadOrKeyPressed(WORD b,int vk){ return pad.Pressed(b)||KeyPressed(vk); }
static bool PadOrKeyDown(WORD b,int vk){ return pad.Down(b)||KBDown(vk); }
static bool LT(){ return pad.LT()||KBDown(VK_LBUTTON); }
static bool RT(){ return pad.RT()||KBDown(VK_RBUTTON); }

static void Flight(Ped p){
    if(!gFlight) return;
    Vector3 pos=ENTITY::GET_ENTITY_COORDS(p,true), f=Fwd(p);
    float sp=gFast?2.8f:0.75f;
    if(PadOrKeyDown(XINPUT_GAMEPAD_RIGHT_SHOULDER,VK_SHIFT)) sp*=2.2f;

    if(PadOrKeyDown(XINPUT_GAMEPAD_DPAD_UP,VK_UP)){
        pos.x+=f.x*sp; pos.y+=f.y*sp; pos.z+=f.z*sp;
    }
    if(PadOrKeyDown(XINPUT_GAMEPAD_DPAD_DOWN,VK_DOWN)){
        pos.x-=f.x*sp; pos.y-=f.y*sp; pos.z-=f.z*sp;
    }
    if(PadOrKeyDown(XINPUT_GAMEPAD_A,VK_SPACE)) pos.z+=sp;
    if(PadOrKeyDown(XINPUT_GAMEPAD_B,VK_CONTROL)) pos.z-=sp;

    ENTITY::SET_ENTITY_VELOCITY(p,0,0,0);
    ENTITY::SET_ENTITY_COORDS_NO_OFFSET(p,pos.x,pos.y,pos.z,true,true,true);
}
static void ToggleFlight(Ped p){
    gFlight=!gFlight;
    if(gFlight){
        gFast=false; Snd("flight_start.wav"); Notify("SUPERMAN: FLIGHT ON");
        PlayAnim(p,"amb@world_human_cheering@male_a","base",4.0f,49);
    }else{
        Snd("flight_end.wav"); Notify("FLIGHT: OFF");
    }
}
static void FastFlight(){
    if(!gFlight) return;
    gFast=!gFast;
    if(gFast){ Snd("boost.wav"); Notify("FAST FLIGHT"); }
    else Notify("HOVER");
}
static void Speed(Ped p){
    if(!gSpeed) return;
    Vector3 f=Fwd(p);
    if(PadOrKeyDown(XINPUT_GAMEPAD_DPAD_UP,VK_UP))
        ENTITY::SET_ENTITY_VELOCITY(p,f.x*20.0f,f.y*20.0f,f.z*3.0f);
}
static void SuperJump(Ped p){
    if(!PadOrKeyPressed(XINPUT_GAMEPAD_Y,'J')) return;
    Vector3 f=Fwd(p);
    ENTITY::APPLY_FORCE_TO_ENTITY(p,1,f.x*12,f.y*12,42,0,0,0,0,false,true,true,false,true);
    Snd("jump.wav");
    PlayAnim(p,"amb@world_human_cheering@male_a","base");
}
static void Punch(Ped p){
    if(!PadOrKeyPressed(XINPUT_GAMEPAD_X,'E')||!Cooldown(280)) return;
    Vector3 a=Pos(p,0,2.0f,0.7f);
    FIRE::ADD_EXPLOSION(a.x,a.y,a.z,0,0.35f,false,true,0.0f);
    Snd("punch.wav");
    PlayAnim(p,"misscarsteal4@actor","actor_berating_loop");
}
static void Heat(Ped p){
    if(!PadOrKeyDown(XINPUT_GAMEPAD_LEFT_SHOULDER,'H')) return;
    Beam(p,90,255,35,20,0.03f);
    Snd("laser.wav");
}
static void Freeze(Ped p){
    if(!(pad.LT()||KBDown('G'))) return;
    Beam(p,35,160,220,255,0.01f);
    Snd("freeze.wav");
}
static void Solar(Ped p){
    if(!(pad.RT()||KeyPressed('R'))||!Cooldown(900)) return;
    Vector3 a=Pos(p,0,2.0f,0.5f);
    FIRE::ADD_EXPLOSION(a.x,a.y,a.z,29,1.2f,false,true,1.0f);
    Snd("solar.wav");
    PlayAnim(p,"amb@world_human_cheering@male_a","base");
}
static void Wind(Ped p){
    if(!PadOrKeyPressed(XINPUT_GAMEPAD_DPAD_RIGHT,'Q')||!Cooldown(700)) return;
    Vector3 a=Pos(p,0,3.0f,0.6f);
    FIRE::ADD_EXPLOSION(a.x,a.y,a.z,2,0.4f,false,true,0.2f);
    Snd("wind.wav");
}
static void Tornado(Ped p){
    if(!PadOrKeyPressed(XINPUT_GAMEPAD_DPAD_LEFT,'T')||!Cooldown(1200)) return;
    Vector3 a=Pos(p,0,6.0f,0.0f);
    FIRE::ADD_EXPLOSION(a.x,a.y,a.z,29,0.8f,false,true,0.5f);
    Snd("tornado.wav");
}
static void KeyboardControls(Ped p){
    if(KeyPressed(VK_F5)){
        gOn=!gOn; Powers(p,gOn);
        if(!gOn){gFlight=false;gFast=false;gSpeed=false;}
        Notify(gOn?"SUPERMAN: ON":"SUPERMAN: OFF");
        Snd(gOn?"power_on.wav":"power_off.wav");
    }
    if(!gOn) return;
    if(KeyPressed(VK_F6)) ToggleFlight(p);
    if(KeyPressed(VK_F7)){
        gSpeed=!gSpeed;
        Notify(gSpeed?"SUPER SPEED: ON":"SUPER SPEED: OFF");
        Snd(gSpeed?"boost.wav":"flight_end.wav");
    }
    if(KeyPressed(VK_F8)){
        gForcedAnim=!gForcedAnim;
        Notify(gForcedAnim?"ANIMATION MODE: ON":"ANIMATION MODE: OFF");
    }
    if(KeyPressed(VK_F9)) FastFlight();
}
void ScriptMain(){
    while(true){
        pad.Update();
        Ped p=PLAYER::PLAYER_PED_ID();

        KeyboardControls(p);

        if(PadOrKeyPressed(XINPUT_GAMEPAD_START,VK_F5)){
            // F5 is handled above; START handles controller.
            if(!gOn){
                gOn=true; Powers(p,true); Notify("SUPERMAN: ON"); Snd("power_on.wav");
            }else{
                gOn=false; Powers(p,false); gFlight=false; gFast=false; gSpeed=false;
                Notify("SUPERMAN: OFF"); Snd("power_off.wav");
            }
        }

        if(gOn){
            Powers(p,true);
            if(PadOrKeyPressed(XINPUT_GAMEPAD_RIGHT_THUMB,VK_F6)) ToggleFlight(p);
            if(PadOrKeyPressed(XINPUT_GAMEPAD_LEFT_THUMB,VK_F7)){
                gSpeed=!gSpeed; Notify(gSpeed?"SUPER SPEED: ON":"SUPER SPEED: OFF");
                Snd(gSpeed?"boost.wav":"flight_end.wav");
            }
            if(PadOrKeyPressed(XINPUT_GAMEPAD_A,VK_F9) && gFlight) FastFlight();
            SuperJump(p); Punch(p); Heat(p); Freeze(p); Solar(p); Wind(p); Tornado(p);
            Flight(p); Speed(p); Animations(p);
        }
        WAIT(0);
    }
}
