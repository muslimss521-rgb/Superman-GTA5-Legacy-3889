#include "script.h"
#include "controller.h"
#include <windows.h>
#include <mmsystem.h>
#include <string>
#include <cmath>
#pragma comment(lib,"winmm.lib")

static bool gOn=false, gFlight=false, gFast=false, gSpeed=false, gForcedAnim=false;
static bool gInvulnerable=true, gRagdollProtect=true, gSounds=true;
static int gAnimMode=0;
static int gMenu=0;
static DWORD gLastAction=0;
static bool gPrevKey[256]{};

static const char* AnimNames[] = {"Hover", "Flight", "Fast Flight", "Attack"};
static const char* MenuItems[] = {
    "Superman", "Flight", "Fast Flight", "Flight Boost", "Super Speed",
    "Super Jump", "Super Strength", "Heat Vision", "Freeze Breath", "Solar Flare",
    "Wind Blast", "Tornado", "Invulnerability", "Ragdoll Protection", "Animations", "Sounds"
};
static const int MENU_COUNT = sizeof(MenuItems)/sizeof(MenuItems[0]);

static bool KeyDown(int vk){ return (GetAsyncKeyState(vk)&0x8000)!=0; }
static bool KeyPressed(int vk){ bool now=KeyDown(vk), was=gPrevKey[vk]; gPrevKey[vk]=now; return now && !was; }
static bool KBDown(int vk){ return KeyDown(vk); }

static void Notify(const char* msg){
    UI::_SET_NOTIFICATION_TEXT_ENTRY("STRING");
    UI::_ADD_TEXT_COMPONENT_STRING((LPSTR)msg);
    UI::_DRAW_NOTIFICATION(false,false);
}
static std::string Root(){ char b[MAX_PATH]={0}; GetCurrentDirectoryA(MAX_PATH,b); return std::string(b); }
static void Snd(const char* name){ if(!gSounds) return; std::string p=Root()+"\\SupermanSounds\\"+name; PlaySoundA(p.c_str(),NULL,SND_FILENAME|SND_ASYNC|SND_NODEFAULT); }
static bool Cooldown(DWORD ms){ DWORD n=GetTickCount(); if(n-gLastAction<ms) return false; gLastAction=n; return true; }
static void Powers(Ped p,bool on){
    ENTITY::SET_ENTITY_INVINCIBLE(p,on && gInvulnerable);
    PLAYER::SET_PLAYER_INVINCIBLE(PLAYER::PLAYER_ID(),on && gInvulnerable);
    PED::SET_PED_CAN_RAGDOLL(p,!(on && gRagdollProtect));
    PED::SET_PED_CAN_RAGDOLL_FROM_PLAYER_IMPACT(p,!(on && gRagdollProtect));
}
static void PlayAnim(Ped p,const char* dict,const char* clip,float rate=8.0f,int flags=49){
    if(!STREAMING::HAS_ANIM_DICT_LOADED((char*)dict)){ STREAMING::REQUEST_ANIM_DICT((char*)dict); return; }
    AI::TASK_PLAY_ANIM(p,(char*)dict,(char*)clip,rate,-8.0f,-1,flags,0.0f,false,false,false);
}
static void LoadAnim(const char* dict){ if(!STREAMING::HAS_ANIM_DICT_LOADED((char*)dict)) STREAMING::REQUEST_ANIM_DICT((char*)dict); }
static void Animations(Ped p){
    LoadAnim("amb@world_human_cheering@male_a");
    LoadAnim("misscarsteal4@actor");
    if(!gForcedAnim || !gFlight) return;
    if(gAnimMode==0) PlayAnim(p,"amb@world_human_cheering@male_a","base",4.0f,49);
    else if(gAnimMode==1) PlayAnim(p,"misscarsteal4@actor","actor_berating_loop",4.0f,49);
    else if(gAnimMode==2) PlayAnim(p,"amb@world_human_cheering@male_a","base",7.0f,49);
    else PlayAnim(p,"misscarsteal4@actor","actor_berating_loop",9.0f,49);
}
static Vector3 Fwd(Ped p){ return ENTITY::GET_ENTITY_FORWARD_VECTOR(p); }
static Vector3 Pos(Ped p,float x,float y,float z){ return ENTITY::GET_OFFSET_FROM_ENTITY_IN_WORLD_COORDS(p,x,y,z); }
static void Beam(Ped p,float range,int r,int g,int b,float damage){
    Vector3 a=Pos(p,0,0.75f,0.65f), f=Fwd(p); Vector3 e={a.x+f.x*range,a.y+f.y*range,a.z+f.z*range};
    GRAPHICS::DRAW_LINE(a.x,a.y,a.z,e.x,e.y,e.z,r,g,b,255);
    FIRE::ADD_EXPLOSION(e.x,e.y,e.z,2,damage,false,true,0.0f);
}
static bool PadOrKeyPressed(WORD b,int vk){ return pad.Pressed(b)||KeyPressed(vk); }
static bool PadOrKeyDown(WORD b,int vk){ return pad.Down(b)||KBDown(vk); }

static void ToggleFlight(Ped p);
static void FastFlight();
static void SuperJump(Ped p);
static void Heat(Ped p);
static void Freeze(Ped p);
static void Solar(Ped p);
static void Wind(Ped p);
static void Tornado(Ped p);
static void DrawTextLine(const char* text,float x,float y,float scale,bool selected){
    UI::SET_TEXT_FONT(selected?1:0); UI::SET_TEXT_SCALE(0.0f,selected?0.40f:0.34f);
    UI::SET_TEXT_COLOUR(selected?0:255,selected?0:255,selected?0:255,255);
    UI::SET_TEXT_DROPSHADOW(2,0,0,0,180); UI::_SET_TEXT_ENTRY("STRING");
    UI::_ADD_TEXT_COMPONENT_STRING((LPSTR)text); UI::_DRAW_TEXT(x,y);
}
static void DrawMenu(Ped p){
    float x=0.055f, y=0.105f, w=0.30f, h=0.030f;
    GRAPHICS::DRAW_RECT(x+w*0.5f,y-0.010f,w,0.055f,8,8,8,235);
    DrawTextLine("SUPERMAN V2 STYLE",x+0.012f,y-0.026f,0.45f,false);
    int first=0; if(gMenu>10) first=gMenu-10; if(first>MENU_COUNT-12) first=MENU_COUNT-12;
    for(int i=first;i<MENU_COUNT && i<first+12;i++){
        int idx=i; float yy=y+(i-first)*h;
        bool sel=(idx==gMenu);
        GRAPHICS::DRAW_RECT(x+w*0.5f,yy+0.012f,w,0.030f,sel?218:25,sel?242:25,sel?216:25,225);
        std::string label=MenuItems[idx];
        bool state=false;
        if(idx==0) state=gOn; else if(idx==1) state=gFlight; else if(idx==2) state=gFast; else if(idx==3) state=gFast; else if(idx==4) state=gSpeed; else if(idx==12) state=gInvulnerable; else if(idx==13) state=gRagdollProtect; else if(idx==15) state=gSounds;
        if(idx==14) label += std::string(" : ")+AnimNames[gAnimMode];
        else if(idx!=5 && idx!=6 && idx!=7 && idx!=8 && idx!=9 && idx!=10 && idx!=11) label += state?" : ON":" : OFF";
        DrawTextLine(label.c_str(),x+0.012f,yy,0.34f,sel);
    }
    DrawTextLine("F5 / START  menu    ENTER / A  select    BACK / B  close",x+0.012f,0.470f,0.27f,false);
    (void)p;
}
static void MenuAction(Ped p){
    switch(gMenu){
    case 0:
        gOn=!gOn; Powers(p,gOn); if(!gOn){gFlight=false;gFast=false;gSpeed=false;}
        Snd(gOn?"power_on.wav":"power_off.wav"); Notify(gOn?"SUPERMAN: ON":"SUPERMAN: OFF"); break;
    case 1: ToggleFlight(p); break;
    case 2: FastFlight(); break;
    case 3: if(gFlight){gFast=true;Snd("boost.wav");Notify("FLIGHT BOOST");} else Notify("ENABLE FLIGHT FIRST"); break;
    case 4: gSpeed=!gSpeed; Snd(gSpeed?"boost.wav":"flight_end.wav"); Notify(gSpeed?"SUPER SPEED: ON":"SUPER SPEED: OFF"); break;
    case 5: { Vector3 f=Fwd(p); ENTITY::APPLY_FORCE_TO_ENTITY(p,1,f.x*12,f.y*12,42,0,0,0,0,false,true,true,false,true); Snd("jump.wav"); gForcedAnim=true; PlayAnim(p,"amb@world_human_cheering@male_a","base"); } break;
    case 6: { Vector3 a=Pos(p,0,2.0f,0.7f); FIRE::ADD_EXPLOSION(a.x,a.y,a.z,0,0.35f,false,true,0.0f); Snd("punch.wav"); PlayAnim(p,"misscarsteal4@actor","actor_berating_loop"); } break;
    case 7: { Beam(p,90,255,35,20,0.03f); Snd("laser.wav"); } break;
    case 8: { Beam(p,35,160,220,255,0.01f); Snd("freeze.wav"); } break;
    case 9: { if(Cooldown(900)){Vector3 a=Pos(p,0,2.0f,0.5f);FIRE::ADD_EXPLOSION(a.x,a.y,a.z,29,1.2f,false,true,1.0f);Snd("solar.wav");PlayAnim(p,"amb@world_human_cheering@male_a","base");} } break;
    case 10: { if(Cooldown(700)){Vector3 a=Pos(p,0,3.0f,0.6f);FIRE::ADD_EXPLOSION(a.x,a.y,a.z,2,0.4f,false,true,0.2f);Snd("wind.wav");} } break;
    case 11: { if(Cooldown(1200)){Vector3 a=Pos(p,0,6.0f,0.0f);FIRE::ADD_EXPLOSION(a.x,a.y,a.z,29,0.8f,false,true,0.5f);Snd("tornado.wav");} } break;
    case 12: gInvulnerable=!gInvulnerable; Powers(p,gOn); Notify(gInvulnerable?"INVULNERABILITY: ON":"INVULNERABILITY: OFF"); break;
    case 13: gRagdollProtect=!gRagdollProtect; Powers(p,gOn); Notify(gRagdollProtect?"RAGDOLL PROTECTION: ON":"RAGDOLL PROTECTION: OFF"); break;
    case 14: gAnimMode=(gAnimMode+1)%4; gForcedAnim=true; Notify(AnimNames[gAnimMode]); Snd("wind.wav"); break;
    case 15: gSounds=!gSounds; Notify(gSounds?"SOUNDS: ON":"SOUNDS: OFF"); break;
    }
}
static void ToggleMenu(){ gMenu=0; }
static void HandleMenu(Ped p){
    if(!KeyPressed(VK_F5) && !pad.Pressed(XINPUT_GAMEPAD_START)) return;
    static bool open=false; open=!open;
    if(!open) return;
    gMenu=0;
    DWORD until=GetTickCount()+1; (void)until;
    while(open){
        pad.Update();
        if(KeyPressed(VK_F5)||pad.Pressed(XINPUT_GAMEPAD_START)){open=false;break;}
        if(KeyPressed(VK_ESCAPE)||KeyPressed(VK_BACK)||pad.Pressed(XINPUT_GAMEPAD_B)){open=false;break;}
        if(KeyPressed(VK_UP)||pad.Pressed(XINPUT_GAMEPAD_DPAD_UP)){gMenu=(gMenu+MENU_COUNT-1)%MENU_COUNT; AUDIO::PLAY_SOUND_FRONTEND(-1,"NAV_UP_DOWN","HUD_FRONTEND_DEFAULT_SOUNDSET",0);}
        if(KeyPressed(VK_DOWN)||pad.Pressed(XINPUT_GAMEPAD_DPAD_DOWN)){gMenu=(gMenu+1)%MENU_COUNT; AUDIO::PLAY_SOUND_FRONTEND(-1,"NAV_UP_DOWN","HUD_FRONTEND_DEFAULT_SOUNDSET",0);}
        if(KeyPressed(VK_LEFT)||pad.Pressed(XINPUT_GAMEPAD_DPAD_LEFT)){if(gMenu==14){gAnimMode=(gAnimMode+3)%4;gForcedAnim=true;} }
        if(KeyPressed(VK_RIGHT)||pad.Pressed(XINPUT_GAMEPAD_DPAD_RIGHT)){if(gMenu==14){gAnimMode=(gAnimMode+1)%4;gForcedAnim=true;} }
        if(KeyPressed(VK_RETURN)||pad.Pressed(XINPUT_GAMEPAD_A)) MenuAction(p);
        DrawMenu(p); WAIT(0);
    }
    gMenu=0;
}
static void Flight(Ped p){
    if(!gFlight) return; Vector3 pos=ENTITY::GET_ENTITY_COORDS(p,true), f=Fwd(p); float sp=gFast?2.8f:0.75f;
    if(PadOrKeyDown(XINPUT_GAMEPAD_RIGHT_SHOULDER,VK_SHIFT)) sp*=2.2f;
    if(PadOrKeyDown(XINPUT_GAMEPAD_DPAD_UP,VK_UP)){pos.x+=f.x*sp;pos.y+=f.y*sp;pos.z+=f.z*sp;}
    if(PadOrKeyDown(XINPUT_GAMEPAD_DPAD_DOWN,VK_DOWN)){pos.x-=f.x*sp;pos.y-=f.y*sp;pos.z-=f.z*sp;}
    if(PadOrKeyDown(XINPUT_GAMEPAD_A,VK_SPACE)) pos.z+=sp; if(PadOrKeyDown(XINPUT_GAMEPAD_B,VK_CONTROL)) pos.z-=sp;
    ENTITY::SET_ENTITY_VELOCITY(p,0,0,0); ENTITY::SET_ENTITY_COORDS_NO_OFFSET(p,pos.x,pos.y,pos.z,true,true,true);
}
static void ToggleFlight(Ped p){ gFlight=!gFlight; if(gFlight){gFast=false;Snd("flight_start.wav");Notify("SUPERMAN: FLIGHT ON");gForcedAnim=true;}else{Snd("flight_end.wav");Notify("FLIGHT: OFF");} }
static void FastFlight(){ if(!gFlight)return; gFast=!gFast; if(gFast){Snd("boost.wav");Notify("FAST FLIGHT");}else Notify("HOVER"); }
static void Speed(Ped p){ if(!gSpeed)return; Vector3 f=Fwd(p); if(PadOrKeyDown(XINPUT_GAMEPAD_DPAD_UP,VK_UP)) ENTITY::SET_ENTITY_VELOCITY(p,f.x*20.0f,f.y*20.0f,f.z*3.0f); }
static void SuperJump(Ped p){ if(!PadOrKeyPressed(XINPUT_GAMEPAD_Y,'J'))return; Vector3 f=Fwd(p); ENTITY::APPLY_FORCE_TO_ENTITY(p,1,f.x*12,f.y*12,42,0,0,0,0,false,true,true,false,true); Snd("jump.wav");gForcedAnim=true;PlayAnim(p,"amb@world_human_cheering@male_a","base"); }
static void Punch(Ped p){ if(!PadOrKeyPressed(XINPUT_GAMEPAD_X,'E')||!Cooldown(280))return; Vector3 a=Pos(p,0,2.0f,0.7f); FIRE::ADD_EXPLOSION(a.x,a.y,a.z,0,0.35f,false,true,0.0f); Snd("punch.wav");PlayAnim(p,"misscarsteal4@actor","actor_berating_loop"); }
static void Heat(Ped p){ if(!PadOrKeyDown(XINPUT_GAMEPAD_LEFT_SHOULDER,'H'))return; Beam(p,90,255,35,20,0.03f); Snd("laser.wav"); }
static void Freeze(Ped p){ if(!PadOrKeyDown(0,'G') && !pad.LT())return; Beam(p,35,160,220,255,0.01f); Snd("freeze.wav"); }
static void Solar(Ped p){ if(!PadOrKeyPressed(XINPUT_GAMEPAD_RIGHT_TRIGGER,'R')||!Cooldown(900))return; Vector3 a=Pos(p,0,2.0f,0.5f); FIRE::ADD_EXPLOSION(a.x,a.y,a.z,29,1.2f,false,true,1.0f); Snd("solar.wav");PlayAnim(p,"amb@world_human_cheering@male_a","base"); }
static void Wind(Ped p){ if(!PadOrKeyPressed(XINPUT_GAMEPAD_DPAD_RIGHT,'Q')||!Cooldown(700))return; Vector3 a=Pos(p,0,3.0f,0.6f); FIRE::ADD_EXPLOSION(a.x,a.y,a.z,2,0.4f,false,true,0.2f); Snd("wind.wav"); }
static void Tornado(Ped p){ if(!PadOrKeyPressed(XINPUT_GAMEPAD_DPAD_LEFT,'T')||!Cooldown(1200))return; Vector3 a=Pos(p,0,6.0f,0.0f); FIRE::ADD_EXPLOSION(a.x,a.y,a.z,29,0.8f,false,true,0.5f); Snd("tornado.wav"); }
static void KeyboardControls(Ped p){
    if(KeyPressed(VK_F2)){gOn=!gOn;Powers(p,gOn);if(!gOn){gFlight=false;gFast=false;gSpeed=false;}Notify(gOn?"SUPERMAN: ON":"SUPERMAN: OFF");Snd(gOn?"power_on.wav":"power_off.wav");}
    if(!gOn)return;
    if(KeyPressed(VK_F6))ToggleFlight(p); if(KeyPressed(VK_F7)){gSpeed=!gSpeed;Notify(gSpeed?"SUPER SPEED: ON":"SUPER SPEED: OFF");Snd(gSpeed?"boost.wav":"flight_end.wav");}
    if(KeyPressed(VK_F10)){gForcedAnim=!gForcedAnim;Notify(gForcedAnim?"ANIMATION MODE: ON":"ANIMATION MODE: OFF");}
    if(KeyPressed(VK_F9))FastFlight();
}
void ScriptMain(){
    while(true){
        pad.Update(); Ped p=PLAYER::PLAYER_PED_ID();
        KeyboardControls(p);
        HandleMenu(p);
        if(gOn){
            Powers(p,true);
            if(PadOrKeyPressed(XINPUT_GAMEPAD_RIGHT_THUMB,VK_F6))ToggleFlight(p);
            if(PadOrKeyPressed(XINPUT_GAMEPAD_LEFT_THUMB,VK_F7)){gSpeed=!gSpeed;Notify(gSpeed?"SUPER SPEED: ON":"SUPER SPEED: OFF");Snd(gSpeed?"boost.wav":"flight_end.wav");}
            if(PadOrKeyPressed(XINPUT_GAMEPAD_A,VK_F9) && gFlight) FastFlight();
            SuperJump(p);Punch(p);Heat(p);Freeze(p);Solar(p);Wind(p);Tornado(p);Flight(p);Speed(p);Animations(p);
        }
        WAIT(0);
    }
}
