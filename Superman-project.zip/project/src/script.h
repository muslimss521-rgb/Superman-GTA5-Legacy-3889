#pragma once
#include "../SDK/inc/main.h"
#include "../SDK/inc/natives.h"
#include "../SDK/inc/types.h"
