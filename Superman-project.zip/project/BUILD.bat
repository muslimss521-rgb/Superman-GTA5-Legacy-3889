@echo off
setlocal
where msbuild >nul 2>nul
if errorlevel 1 (
  echo MSBuild not found. Install Visual Studio with Desktop development with C++.
  exit /b 1
)
msbuild "%~dp0Superman.sln" /p:Configuration=Release /p:Platform=x64
if errorlevel 1 exit /b 1
echo.
echo READY: %~dp0build\Superman.asi
